export const DB_NAME='kodr'
